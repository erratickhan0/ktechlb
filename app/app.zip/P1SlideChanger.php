<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class P1SlideChanger extends Model
{
    protected $fillable  = ['heading','description','p1_id'];
}
