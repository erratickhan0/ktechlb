<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Section6 extends Model
{
    protected $fillable = ['brand_id','design_id','heading','description','btn_text','btn_link','btn_show'];
}
