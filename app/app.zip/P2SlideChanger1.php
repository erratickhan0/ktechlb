<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class P2SlideChanger1 extends Model
{
   protected $fillable = ['title','description','button_link','p2_id'];
}
