<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SliderSection2 extends Model
{
    protected $fillable = ['left_description','right_description','brand_id','design_id','image','mime_type'];
}
