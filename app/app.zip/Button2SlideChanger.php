<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Button2SlideChanger extends Model
{
    protected $fillable = ['description'];
}
