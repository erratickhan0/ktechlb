<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class P2SlideChanger3 extends Model
{
    //
}
