<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class D1SliderSection extends Model
{
    protected $fillable = ['title','description','colour','file_path'];
}
