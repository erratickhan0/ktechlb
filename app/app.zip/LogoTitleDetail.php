<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LogoTitleDetail extends Model
{
    protected $fillable = ['logo_title_section_id','heading','mime_type','description'];
}
