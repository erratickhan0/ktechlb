<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class D1SliderSection3 extends Model
{
    protected $table = 'd1_slider_sections3s';
   protected $fillable = ['title','description'];
}
