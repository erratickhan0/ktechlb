<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class D1SliderSection2 extends Model
{
    protected $table= 'd1_slider_sections2';
    protected $fillable=['description','btn_text','btn_link','btn_show'];
}
