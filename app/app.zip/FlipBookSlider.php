<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FlipBookSlider extends Model
{
    //
}
