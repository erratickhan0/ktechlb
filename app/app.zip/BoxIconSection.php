<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BoxIconSection extends Model
{
   protected $fillable = ['brand_id','title','description','box_icon'];
}
