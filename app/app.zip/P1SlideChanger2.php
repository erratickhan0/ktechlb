<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class P1SlideChanger2 extends Model
{
    protected $fillable  = ['heading','p1_id','btn_text','btn_link','btn_show'];
}
